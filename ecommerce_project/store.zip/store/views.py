from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, redirect
from .models import Product, Order

def store_home(request):
    return redirect('product_list')


def product_list(request):
    products = Product.objects.all()
    return render(request, 'store/product_list.html', {'products': products})

def add_to_cart(request, product_id):
    product = Product.objects.get(id=product_id)
    order, created = Order.objects.get_or_create(user=request.user, is_completed=False)
    order.products.add(product)
    order.total_price += product.price
    order.save()
    return redirect('product_list')

def view_cart(request):
    order = Order.objects.get(user=request.user, is_completed=False)
    return render(request, 'store/view_cart.html', {'order': order})
